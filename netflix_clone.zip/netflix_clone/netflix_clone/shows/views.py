from django.shortcuts import render
from django.shortcuts import get_object_or_404, redirect
from django.http import  HttpResponse
from shows.models import User_signup,Subscriptions,ContentManager_adult,ContentManager_kid,upcomming_release
from django.contrib import messages
from django.urls import reverse
from django.contrib.auth.hashers import make_password
from django.contrib.auth.decorators import login_required
from shows.forms import *

from django.shortcuts import get_object_or_404

def loginpage(request):
    if request.method == "POST":
        emailid = request.POST.get('emailid') 
        user = User_signup.objects.filter(emailid=emailid).first()
        if emailid == "administration@netflix.in":    
            return redirect('admin_access') 
        
        if emailid == "datauploader@netflix.in":       
             return render(request,"content_choose.html")
        if user:
            if user.agelimit is not None and user.agelimit <= 18:
                return redirect('kview')
                
            else:
                return redirect('viewshows')
               
            
    return render(request,'all_login_page.html')

def signuppage(request):

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password') 
        emailid = request.POST.get('emailid')
        location = request.POST.get('location')  
        agelimit=request.POST.get('agelimit')
        phonenumber=request.POST.get('phonenumber') 
        referal_mail=request.POST.get('referal_mail')  
        
        if username and emailid and phonenumber:
            if User_signup.objects.filter(username=username).exists():
                messages.error(request, "Username Not Available.")
            elif User_signup.objects.filter(emailid=emailid).exists():
                messages.error(request, "Emailid already exists.")
            elif User_signup.objects.filter(phonenumber=phonenumber).exists():
                messages.error(request, "Phonenumber already exists.")
            elif not phonenumber.isdigit():
                messages.error(request, "Phone number must contain only digits.")
            elif len(phonenumber) != 10:
                messages.error(request, "Phone number must be exactly 10 digits.")
            else:
                hashed_password = password
                user = User_signup(
                    username=username,
                    password=hashed_password,
                    emailid=emailid,
                    location=location,
                    agelimit=agelimit,
                    phonenumber=phonenumber,
                    referal_mail=referal_mail
                )
                user.save()  

                request.session['username'] = user.username
                price = 149 if int(agelimit) < 18 else 199
                request.session['price'] = price 
                
                return redirect('user_subscription')

    return render(request,"subscribers_signin.html")  

def user_subscription(request):
    username = request.session.get('username', '')
    price = request.session.get('price', 0)
    
    if request.method == 'POST':
        cardno = request.POST.get('cardno')
        card_cv = request.POST.get('card_cv')
        otp_number = request.POST.get('otp_number')
        plan = request.POST.get('plan')

        if not cardno or not cardno.replace("-", "").isdigit():
            messages.error(request, "Card number must contain only digits.")
        elif len(cardno.replace("-", "")) != 16:
            messages.error(request, "Card number must be exactly 16 digits.")
        elif not otp_number.isdigit():
            messages.error(request, "OTP must contain only digits.")
        else:
            pay = Subscriptions(
                cardno=cardno.replace("-", ""),
                card_cv=card_cv,
                otp_number=otp_number,
                plan=plan  
            )
            pay.save()

            request.session.pop('username', None)
            request.session.pop('price', None)

            return redirect("all_login")

    return render(request, "subscriptions.html", {"username": username, "price": price})


def admin_access(request):
    users_access = User_signup.objects.all()
    return render(request, 'onlyadmin.html', {'users_access': users_access})

def content(request):
    return render(request,"content_choose.html")

def content_details(request):
    a_details=ContentManager_adult.objects.all()
    k_details=ContentManager_kid.objects.all()
    u_details=upcomming_release.objects.all()
    return render(request,"fullcontents.html",{"adultdetails":a_details,"kidsdetails":k_details,"upconent":u_details})

def remove_content(request,rem_id):
    try:
        a_content=ContentManager_adult.objects.get(id=rem_id)
        a_content.delete()


        k_content=ContentManager_kid.objects.get(id=rem_id)
        k_content.delete()
    except:
        print("Error during deletion")
        
    return redirect('alluploades')

def uc(request,idd):
    u=upcomming_release.objects.get(id=idd)
    u.delete()
    return redirect('alluploades')

def Ban_user(request,user_id):
    user = User_signup.objects.get(id=user_id)
    user.delete()
    return redirect("admin_access")

def  Update_user(request,update_id):
    updateuser=get_object_or_404(User_signup, id=update_id)  
    if request.method=="POST":
        print("Form submitted with data:", request.POST)
        up=Userform(request.POST,instance=updateuser)
        if up.is_valid():
            up.save()
            return redirect('admin_access')
    else:
       up=Userform(instance=updateuser)
    return render(request,"update_user.html",{"userpro":up,"person":updateuser}) 

def shows(request):
    if request.method == 'POST':
        form=Contentform(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            files=form.instance
        return redirect('shows') 
        
    else:
        files = Contentform()
    return render(request, 'showcontents.html',{'files':files})
    
def viewshows(request):
    
    showfiles= ContentManager_adult.objects.all() 
    adult_content = upcomming_release.objects.filter(is_kid=False)
    return render(request, 'viewcontents.html', {'showfiles': showfiles,'contents': adult_content,})

def upcome(request):
    if request.method == 'POST':
        form = Upcome_form(data=request.POST, files=request.FILES)
        if form.is_valid():
            form.save()  
            return redirect('upcomes')  
    else:
        form = Upcome_form()  
    return render(request, 'upcomes.html', {'form': form}) 
 
def kidsshows(request):
    if request.method == 'POST':
        form=Contentform_kid(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            files_kid=form.instance 
        return render(request, 'kids_showcontents.html')     
    else:
        files_kid = Contentform_kid()
    return render(request, 'kids_showcontents.html',{'files_kid':files_kid})

def kids_viewshows(request):
    showfiles_kids= ContentManager_kid.objects.all()     
    kids_content = upcomming_release.objects.filter(is_kid=True)
    return render(request, 'viewcontents_kid.html', {'showfiles_kids': showfiles_kids,'contents': kids_content,})

