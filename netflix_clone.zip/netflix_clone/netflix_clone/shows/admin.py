from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(ContentManager_adult)
admin.site.register(ContentManager_kid)
admin.site.register(upcomming_release)