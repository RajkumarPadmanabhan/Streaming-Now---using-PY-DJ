from django.db import models

# Create your models here.
class User_signup(models.Model):
    username=models.CharField(max_length=30)
    emailid=models.EmailField(max_length=50)
    agelimit=models.IntegerField()
    location=models.CharField(max_length=50)
    password=models.CharField(max_length=10)
    phonenumber=models.IntegerField()
    referal_mail=models.CharField(max_length=10)
    
    class Meta:
        db_table="UserSignup"

class Admin_user(models.Model):
    admin_useraccess = models.OneToOneField(User_signup, on_delete=models.CASCADE)
    admin_access_level = models.CharField(max_length=30, default="Full Access")

    class Meta:
        db_table="AdminOnly"

class Subscriptions(models.Model):
    cardno=models.CharField(max_length=16)
    card_cv=models.DateField()
    otp_number=models.IntegerField()
    plan=models.IntegerField()

    class Meta:
        db_table="Subscriptions"

class ContentManager_adult(models.Model):
    title = models.CharField(max_length=100)
    thumbnail = models.ImageField(upload_to='thumbnails_adt/')
    description = models.TextField()
    video = models.FileField(upload_to='video_adt/%y')
    
    class Meta:
        db_table="Adult_Contents"

class ContentManager_kid(models.Model):
    kids_title = models.CharField(max_length=100)
    kids_thumbnail = models.ImageField(upload_to='thumbnails_kid/')
    kids_description = models.TextField()
    kids_video = models.FileField(upload_to='video_kid/%y')

    class Meta:
        db_table="Kid_Contents"

class upcomming_release(models.Model):
    Main_Title = models.CharField(max_length=255)
    Poster= models.ImageField(upload_to='img_upcome/')
    Trailer = models.FileField(upload_to='vid_upcome/%y')
    is_kid = models.BooleanField(default=True)

    class Meta:
        db_table="upcommings"
