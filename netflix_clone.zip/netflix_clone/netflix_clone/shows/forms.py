from django import forms
from shows.models import User_signup,ContentManager_adult,ContentManager_kid,upcomming_release

class Userform(forms.ModelForm):
    class Meta:
            model = User_signup
            # fields="__all__"
            exclude = ["password"]

class Contentform(forms.ModelForm):
      class Meta:
            model= ContentManager_adult
            fields="__all__"
            

class Contentform_kid(forms.ModelForm):
      class Meta:
            model= ContentManager_kid
            fields="__all__"
            
class Upcome_form(forms.ModelForm):
      class Meta:
            model=upcomming_release
            fields="__all__"

            