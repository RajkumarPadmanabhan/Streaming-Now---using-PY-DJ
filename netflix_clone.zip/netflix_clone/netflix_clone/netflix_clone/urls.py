"""
URL configuration for netflix_clone project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from shows.views import *
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',loginpage,name="all_login"),
    path('signup/',signuppage,name="signup"),
    path("onlyadmin",admin_access,name='admin_access'),
    path('banuser/<int:user_id>',Ban_user,name='banuser'),
    path('updateuser/<int:update_id>',Update_user,name='Updateuser'),
    path('subscriptions',user_subscription,name="user_subscription"),
    path('shows',shows,name="shows"),
    path('kshow',kidsshows,name="kshow"),
    path('viewshows',viewshows,name="viewshows"),
    path('kview',kids_viewshows,name="kview"),
    path('content',content,name='content'),
    path("alluploades",content_details,name="alluploades"),
    path("recontent/<int:rem_id>",remove_content,name="recontent"),
    path('upcomes',upcome,name="upcomes"),
    path('uc/<int:idd>',uc,name='uc'),
    
   
 
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

